
export function halfOf(x){
    return x / 2;
}

export function multiply(x,y){
    return x * y;
}
